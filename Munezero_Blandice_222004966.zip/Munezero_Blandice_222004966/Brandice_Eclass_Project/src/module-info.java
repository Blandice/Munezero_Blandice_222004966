/**
 * 
 */
/**
 * 
 */
module Brandice_Eclass_Project {
	requires java.desktop;
	requires java.sql;
}